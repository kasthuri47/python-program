Python 3.15.0a7 (tags/v3.15.0a7:6024d3c, Mar 10 2026, 13:09:10) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
================ RESTART: C:/Users/ELCOT/Desktop/python/input.py ===============
5
5
>>> 
================ RESTART: C:/Users/ELCOT/Desktop/python/input.py ===============
enter:5
5
>>> 
=== RESTART: C:/Users/ELCOT/AppData/Local/Programs/Python/Python315/python.py ==
num5
num7
12
