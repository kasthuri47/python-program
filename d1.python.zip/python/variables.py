name=("kaasthuri")
print(name)
